package backend.logic.models.cards;

public class HealthCard extends Card {
}
