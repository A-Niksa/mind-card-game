package backend.logic.models.cards;

public class NinjaCard extends Card {
}
