package backend.logic.models.cards;

public abstract class Card {
}
