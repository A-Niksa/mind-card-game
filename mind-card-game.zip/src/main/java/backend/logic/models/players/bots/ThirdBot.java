package backend.logic.models.players.bots;

import backend.logic.games.components.Hand;

public class ThirdBot extends Bot {
    protected ThirdBot(int joinedGameId) {
        super(joinedGameId, 9, 20);
    }
}
