package api.dataeggs.ninjarequest;

public enum NinjaRequestStatus {
    WAITING,
    ACCEPTED,
    REJECTED
}
