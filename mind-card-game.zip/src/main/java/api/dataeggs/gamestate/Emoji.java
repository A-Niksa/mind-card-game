package api.dataeggs.gamestate;

public enum Emoji {
    ANGRY,
    LAUGHING,
    LOVING,
    CRYING,
    NOTHING
}
