package utils.jsonparsing.literals.utils;

import backend.logic.games.Game;
import backend.logic.games.GameManager;
import backend.logic.games.components.JudgeUtils;
import backend.logic.models.cards.NumberedCard;
import backend.logic.models.cards.NumberedCardComparator;
import backend.logic.models.players.Player;

import java.util.ArrayList;
import java.util.List;

public class MakingMoveUtils {
    public static void dropCardInGameManager(Game game, int playerId, int cardIndex) {
        NumberedCard card = getCardAndRemoveByIndex(game, playerId, cardIndex);
        GameManager.dropCardInGame(game.getGameId(), playerId, card);
    }

    private static NumberedCard getCardAndRemoveByIndex(Game game, int playerId, int cardIndex) {
        Player player = getPlayerById(game, playerId);
        NumberedCard numberedCard = getCardByIndex(player, cardIndex);;
        player.getHand().removeCard(cardIndex);
        return numberedCard;
    }

    private static NumberedCard getCardByIndex(Player player, int cardIndex) {
        List<NumberedCard> cardsList = player.getHand().getNumberedCardsList();
        cardsList.sort(new NumberedCardComparator());
        return cardsList.get(cardIndex);
    }

    public static int getSmallestCardInPlayersHands(Game game) {
        ArrayList<NumberedCard> cardsOfAllPlayersList = JudgeUtils.getCardsOfAllPlayersList(game);
        cardsOfAllPlayersList.sort(new NumberedCardComparator());

        return cardsOfAllPlayersList.get(0).getCardNumber();
    }

    public static boolean moveCausesHealthLoss(Game game, int playerId) {
        int cardNumber = getCardNumberByIndex(game, playerId);
        return !JudgeUtils.cardToDropIsTheMinOfAllPlayers(game, cardNumber);
    }

    public static boolean moveRespectsGroundOrder(Game game, int playerId) {
        int cardNumber = getCardNumberByIndex(game, playerId);
        int topCardNumber = getTopCardNumber(game);
        if (topCardNumber == -1) {
            return true;
        }

        return topCardNumber < cardNumber;
    }

    private static int getTopCardNumber(Game game) {
        NumberedCard topCard = game.getDroppingGround().peek();
        if (topCard == null) {
            return -1;
        }

        return topCard.getCardNumber();
    }

    private static int getCardNumberByIndex(Game game, int playerId) {
        List<NumberedCard> cardsOfPlayerList = getPlayerById(game, playerId)
                .getHand().getNumberedCardsList();
        cardsOfPlayerList.sort(new NumberedCardComparator());
        return cardsOfPlayerList.get(0).getCardNumber();
    }

    private static Player getPlayerById(Game game, int playerId) {
        for (Player player : game.getPlayersList()) {
            if (playerId == player.getPlayerId()) {
                return player;
            }
        }

        return null;
    }
}
