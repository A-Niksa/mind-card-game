package utils.jsonparsing.literals.dataeggs.gamestate;

public enum Emoji {
    ANGRY,
    LAUGHING,
    LOVING,
    CRYING,
    NOTHING
}
