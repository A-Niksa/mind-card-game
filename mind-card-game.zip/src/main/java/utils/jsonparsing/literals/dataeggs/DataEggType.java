package utils.jsonparsing.literals.dataeggs;

public enum DataEggType {
    MAKING_MOVE_EGG,
    NEW_GAME_EGG,
    GAME_STATE_EGG,
    JOINABLE_GAMES_EGG,
    HAND_EGG,
    DROPPED_CARD_EGG,
    EMOJI_EGG,
    NINJA_REQUEST_EGG
}
