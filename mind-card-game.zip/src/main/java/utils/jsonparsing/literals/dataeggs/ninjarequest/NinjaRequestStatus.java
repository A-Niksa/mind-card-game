package utils.jsonparsing.literals.dataeggs.ninjarequest;

public enum NinjaRequestStatus {
    WAITING,
    ACCEPTED,
    REJECTED
}
